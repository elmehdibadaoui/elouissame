<?php $__env->startSection('content'); ?>
    <div class="page-content browse container-fluid">
		
		<div class="row">
			<div class="col-md-3">
				<div class="card card-success">
					<div class="card-block">
						<h4 class="card-title text-white ng-binding">Étudiants</h4>
						<div class="text-right">
							<h2 class="font-light m-b-0 text-white ng-binding"><i class="icon voyager-people"></i> <?php echo e(App\Etudiant::count()); ?></h2>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="card card-info">
					<div class="card-block">
						<h4 class="card-title text-white ng-binding">Parents</h4>
						<div class="text-right">
							<h2 class="font-light m-b-0 text-white ng-binding"><i class="icon voyager-group"></i>  <?php echo e(App\Pere::count()); ?></h2>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="card card-danger">
					<div class="card-block">
						<h4 class="card-title text-white ng-binding">Personnel</h4>
						<div class="text-right">
							<h2 class="font-light m-b-0 text-white ng-binding"><i class="icon voyager-group"></i>  <?php echo e(App\Personnel::count()); ?></h2>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="card card-primary">
					<div class="card-block">
						<h4 class="card-title text-white ng-binding">CA de la Semaine</h4>
						<div class="text-right">
							<h2 class="font-light m-b-0 text-white ng-binding"><i class="icon voyager-dollar"></i>  <?php 
								$fromDate = \Carbon\Carbon::now()->subDays(7); 
								$toDate = \Carbon\Carbon::now();
								echo App\Paiement::whereBetween('created_at', array($fromDate, $toDate) )->sum('total');
							 ?></h2>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
		<div class="panel panel-bordered">
			<div class="panel-header">
				<h4 class="panel-title">Situation financiere des Étudiants</h4>
			</div>
			<div class="panel-body">
				<table class="table table-hover">
					<thead>
						<tr>
						<th width="20%">#</th>
						<th width="30%">Nom</th>
						<th width="15%">Statu</th>
						<th width="20%">Dernier Paiement</th>
						<th width="15%">Montant</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = App\Etudiant::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$last_paiement = $item->getLastPaiment();
							$prix_paiement = $item->getPaimentPrix();
							
							$now           = \Carbon\Carbon::now()->subMonth();
							$end_date      = \Carbon\Carbon::parse($last_paiement->date);
							$paye     	   = $now>$end_date ? true : false;
						 ?>
						<tr>
							<th scope="row"><?php echo e($loop->index+1); ?></th>
							<td><?php echo e($item->name); ?></td>
							<td>
								<?php  echo $paye ? '<span class="label label-danger">Non Payé</span>' : '<span class="label label-success">Payé</span>'  ?>
							</td>
							<td><?php echo e($end_date->format('d/m/Y')); ?></td>
							<td><?php echo e($prix_paiement ? $prix_paiement : 0); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		
	
		<div class="panel panel-bordered">
			<div class="panel-header">
				<h4 class="panel-title">Rappels Financière d’aujourd’hui</h4>
			</div>
			<div class="panel-body">
				<table class="table table-hover">
					<caption>Les Revenus</caption>
					<thead>
						<tr>
						<th width="20%">#</th>
						<th width="30%">Nom</th>
						<th width="20%">Montant</th>
						<th width="30%">Date d'Operation</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$total_revenus = 0;
						 ?>
						<?php $__currentLoopData = App\Paiement::where('is_etudiant', 1)->whereDate('created_at', Carbon\Carbon::today())->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$user = App\Etudiant::find($item->user_id);
							$total_revenus += $item->total;
						 ?>
						<tr>
							<th scope="row"><?php echo e($loop->index+1); ?></th>
							<td><?php echo e($user->name); ?></td>
							<td><?php echo e($item->total); ?></td>
							<td><?php echo e($item->created_at ? Carbon\Carbon::parse($item->created_at)->format('d/m/Y H:i') : "-"); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr style="font-weight:bold">
							<th scope="row">Total</th>
							<td colspan="3"><?php echo e($total_revenus); ?> Dhs</td>
						</tr>
					</tbody>
				</table>
				<table class="table table-hover">
					<caption>Les Dépenses</caption>
					<thead>
						<tr>
						<th width="20%">#</th>
						<th width="30%">Nom</th>
						<th width="20%">Montant</th>
						<th width="30%">Date d'Operation</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$total_depences = 0;
						 ?>
						<?php $__currentLoopData = App\Paiement::where('is_etudiant', 0)->whereDate('created_at', Carbon\Carbon::today())->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							$user = App\Personnel::find($item->user_id);
							$total_depences += $item->total;
						 ?>
						<tr>
							<th scope="row"><?php echo e($loop->index+1); ?></th>
							<td><?php echo e($user->name); ?></td>
							<td><?php echo e($item->total); ?></td>
							<td><?php echo e($item->created_at ? Carbon\Carbon::parse($item->created_at)->format('d/m/Y H:i') : "-"); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr style="font-weight:bold">
							<th scope="row">Total</th>
							<td colspan="3"><?php echo e($total_depences); ?> Dhs</td>
						</tr>
					</tbody>
				</table>
				<div class="panel <?php echo $total_revenus>$total_depences ? "panel-success" : "panel-danger" ?> ">
					<div class="panel-body">
						La recette d’aujourd’hui est : <strong style="font-weight:bold"><?php echo e($total_revenus - $total_depences); ?> Dhs </strong>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
	.card{
		padding: 15px;
	}
	.card-title {
		margin-bottom: 20px;
	}
	.text-white {
		color: #fff!important;
	}
	.card-success{background:#1abc9c;border-color:#1abc9c}
	.card-danger{background:#e74c3c;border-color:#e74c3c}
	.card-warning{background:#f39c12;border-color:#f39c12}
	.card-info{background:#3498db;border-color:#3498db}
	.card-primary{background:#7460ee;border-color:#7460ee}
	.card-dark{background:#2f3d4a;border-color:#2f3d4a}
	.card-megna{background:#01c0c8;border-color:#01c0c8}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>