<?php

return [
    'page'           => 'pagină|pagini',
    'page_link_text' => 'Toate paginile',
    'page_text'      => 'În baza de date există :count :string',
    'post'           => 'postare|postări',
    'post_link_text' => 'Toate postările',
    'post_text'      => 'În baza de date există :count :string',
    'user'           => 'utilizator|utilizatori',
    'user_link_text' => 'Toți utilizatorii',
    'user_text'      => 'În baza de date există :count :string',
];
