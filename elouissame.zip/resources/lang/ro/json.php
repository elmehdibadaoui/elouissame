<?php

return [
    'invalid'           => 'format JSON invalid',
    'invalid_message'   => 'Ați introdus un format JSON invalid',
    'valid'             => 'Format JSON corect',
    'validation_errors' => 'Eroare la verificarea datelor',
];
