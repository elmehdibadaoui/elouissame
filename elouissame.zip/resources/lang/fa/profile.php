<?php

return [
    'avatar'           => 'آواتار',
    'edit'             => 'ویرایش پروفایل من',
    'edit_user'        => 'ویرایش کاربر',
    'password'         => 'رمز عبور',
    'password_hint'    => 'برای یکسان بودن خالی بگذارید',
    'role'             => 'نقش',
    'roles'            => 'نقش ها',
    'role_default'     => 'نقش پیشفرض',
    'roles_additional' => 'نقش های دیگر',
    'user_role'        => 'نقش کاربر',
];
