<?php

return [
    'avatar'        => 'Avatar',
    'edit'          => 'Ubah Profil',
    'edit_user'     => 'Ubah User',
    'password'      => 'Password',
    'password_hint' => 'Kosongkan apabila sama',
    'role'          => 'Role',
    'user_role'     => 'User Role',
];
