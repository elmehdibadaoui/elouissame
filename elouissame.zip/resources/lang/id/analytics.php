<?php

return [
    'by_pageview'  => 'By pageview',
    'by_sessions'  => 'By sessions',
    'by_users'     => 'By users',
    'no_client_id' => 'Untuk melihat analytics kamu membutuhkan google analytics client id dan '.
                                 'menambahkannya ke pengaturan dengan menggunakan key <code>google_analytics_client_id'.
                                 '</code>. Dapatkan key dari Google developer console:',
    'set_view'               => 'Pilih View',
    'this_vs_last_week'      => 'Minggu ini vs Minggu lalu',
    'this_vs_last_year'      => 'Tahun ini vs Tahun lalu',
    'top_browsers'           => 'Top Browsers',
    'top_countries'          => 'Top Countries',
    'various_visualizations' => 'Bermacam visualisasi',
];
