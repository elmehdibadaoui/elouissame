<?php

return [
    'avatar'        => 'Avatar',
    'edit'          => 'Edytuj mój profil',
    'edit_user'     => 'Edytuj użytkownika',
    'password'      => 'Hasło',
    'password_hint' => 'Pozostaw puste, aby zachować bieżące',
    'role'          => 'Role',
    'user_role'     => 'Role użytkownika',
];
