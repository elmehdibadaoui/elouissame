<?php

return [
    'invalid'           => 'Json inválido',
    'invalid_message'   => 'Parece que has introducido algún JSON inválido.',
    'valid'             => 'Json Válido',
    'validation_errors' => 'Errores de validación',
];
