<?php

return [
    'avatar'        => 'Avatar',
    'edit'          => 'Editar mi perfil',
    'edit_user'     => 'Editar usuario',
    'password'      => 'Contraseña',
    'password_hint' => 'Dejar vacío para mantener el mismo',
    'role'          => 'Rol',
    'user_role'     => 'Rol del usuario',
];
