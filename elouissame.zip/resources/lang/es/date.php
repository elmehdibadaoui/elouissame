<?php

return [
    'last_week' => 'La semana pasada',
    'last_year' => 'El año pasado',
    'this_week' => 'Esta semana',
    'this_year' => 'Este año',
];
