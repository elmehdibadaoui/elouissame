<?php

return [
    'footer_copyright'  => 'Feito con <i class = "voyager-heart"> </i> por',
    'footer_copyright2' => 'Feito con ron e incluso máis ron',
];
