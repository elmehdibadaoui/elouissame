<?php

return [
    'invalid'           => 'Json inválido',
    'invalid_message'   => 'Parece que introduciches algún JSON inválido.',
    'valid'             => 'Json Válido',
    'validation_errors' => 'Errores de validación',
];
