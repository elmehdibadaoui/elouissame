<?php

return [
    'loggingin'    => 'Iniciando sesión',
    'signin_below' => 'Ingresar abaixo:',
    'welcome'      => 'Benvido a Voyager. O administrador desaparecido de Laravel ',
];
