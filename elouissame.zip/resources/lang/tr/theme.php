<?php

return [
    'footer_copyright'  => '<i class="voyager-heart"></i> ile yapıldı',
    'footer_copyright2' => 'Rom ve daha da fazla romla yapılmış',
];
