<?php

return [
    'page'           => 'Sayfa|Sayfalar',
    'page_link_text' => 'Tüm sayfaları Görüntüle',
    'page_text'      => ' :count kadar :string veritabanınızda. Tıklayarak tüm sayfaları görün.',
    'post'           => 'Gönderi|Gönderiler',
    'post_link_text' => 'Tüm Gönderileri Görüntüle',
    'post_text'      => ':count kadar :string veritabanınızda. Tıklayarak tüm Gönderileri görün.',
    'user'           => 'Kullanıcı|Kullanıcılar',
    'user_link_text' => 'Tüm Kullanıcları Görüntüle',
    'user_text'      => ':count kadar :string veritabanınızda. Tıklayarak tüm kullanıcıları görün.',
];
