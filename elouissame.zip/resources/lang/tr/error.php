<?php

return [
    'symlink_created_text'   => 'Kayıp depolama alanı sembolik bağlantısı sizin için onardık.',
    'symlink_created_title'  => 'Kayıp depolama alanı sembolik bağlantısı oluşturuldu.',
    'symlink_failed_text'    => 'Kayıp depolama alanı sembolik bağlantısını sizin için oluştururken sorun alıyoruz. Sunucunuz bunu desteklemiyor gibi görünüyor.',
    'symlink_failed_title'   => 'Depolama alanı sembolik bağlantısı oluşturulamadı.',
    'symlink_missing_button' => 'Düzelt',
    'symlink_missing_text'   => 'Depolama alanı sembolik bağlantısı bulamadık. Bu sorun medya dosyalarının tarayıcıdan yüklenmesinden kaynaklı olabilir.',
    'symlink_missing_title'  => 'Depolama alanı sembolik bağlantısı eksik.',
];
