<?php

return [
    'invalid'           => 'Geçersiz JSON',
    'invalid_message'   => 'Geçersiz bir JSON gibi görünüyor',
    'valid'             => 'Geçerli JSON',
    'validation_errors' => 'Doğrulama Hatası',
];
