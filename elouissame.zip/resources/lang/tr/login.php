<?php

return [
    'loggingin'    => 'Giriş yap',
    'signin_below' => ' Below: oturum aç',
    'welcome'      => "Voyager a hoş geldiniz , Laravel'in aranan yönetim paneli",
];
