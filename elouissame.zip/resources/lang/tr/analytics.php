<?php

return [
    'by_pageview'            => 'Sayfa görüntülenmesine göre',
    'by_sessions'            => 'Oturuma göre',
    'by_users'               => 'Kullanıcıya göre',
    'no_client_id'           => 'Analitiği görmek için Google Analytics İstemci Kimliği almanız ve <code>google_analytics_client_id</code> kodu içinde ayarlarınıza eklemeniz gerekmektedir. Anahtar kodunuzu Google Geliştirici Konsolu\'ndan alın:',
    'set_view'               => 'Görünüm seçin',
    'this_vs_last_week'      => 'Bu Hafta vs Geçen Hafta',
    'this_vs_last_year'      => 'Bu Yıl vs Geçen Yıl',
    'top_browsers'           => 'En çok girilen tarayıcı türü',
    'top_countries'          => 'En çok girilen ülke',
    'various_visualizations' => 'Çeşitli görünümler',
];
