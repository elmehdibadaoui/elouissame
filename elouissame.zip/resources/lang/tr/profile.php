<?php

return [
    'avatar'        => 'Avatar',
    'edit'          => 'Profilimi Düzenle',
    'edit_user'     => 'Kullanıcıyı Düzenle',
    'password'      => 'Şifre',
    'password_hint' => 'Şifrenin aynı kalması için boş bırakın',
    'role'          => 'Rol',
    'user_role'     => 'Kullanıcı Rolü',
];
