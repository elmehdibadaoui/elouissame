<?php

return [
    'field_password_keep'          => 'Aynı kalması için boş bırakın',
    'field_select_dd_relationship' => ':method methodu ile :class sınıfı içinde uygun bir ilişki kurduğunuzdan emin olun.',
    'type_checkbox'                => 'Çoklu Seçim Kutuları',
    'type_codeeditor'              => 'Kod Editörü',
    'type_file'                    => 'Dosya',
    'type_image'                   => 'Resim',
    'type_radiobutton'             => 'Opsiyon Kutuları',
    'type_richtextbox'             => 'Metin Editörü',
    'type_selectdropdown'          => 'Seçim Kutusu',
    'type_textarea'                => 'Metin Alanı',
    'type_textbox'                 => 'Metin Kutusu',
];
