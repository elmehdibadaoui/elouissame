<?php

return [
    'field_password_keep'          => 'اتركه فارغ لعدم التعديل',
    'field_select_dd_relationship' => 'تأكد من إعداد العلاقة المناسبة في الطريقة :method الخاصة بالمعرف :class',

    'type_checkbox'       => 'مربع اختيار Checkbox',
    'type_codeeditor'     => 'محرر أكواد Code Editor',
    'type_file'           => 'ملف',
    'type_image'          => 'صورة',
    'type_radiobutton'    => 'زر اختيار من متعدد Radio Button',
    'type_richtextbox'    => 'مربع نص منسق Rich Textbox',
    'type_selectdropdown' => 'قائمة تحديد منسدلة Dropdown',
    'type_textarea'       => 'منطقة نص Text Area',
    'type_textbox'        => 'مربع نص Text Box',
];
