<?php

return [
    'field_password_keep'          => 'Zanechte prázdné pro zachování aktuálního hesla',
    'field_select_dd_relationship' => 'Ujistěte se, že je nastavený správný vztah pro :method metodu '.
                                      'třídy :class',
    'type_checkbox'       => 'Check Box',
    'type_codeeditor'     => 'Code Editor',
    'type_file'           => 'File',
    'type_image'          => 'Image',
    'type_radiobutton'    => 'Radio Button',
    'type_richtextbox'    => 'Rich Textbox',
    'type_selectdropdown' => 'Select Dropdown',
    'type_textarea'       => 'Text Area',
    'type_textbox'        => 'Text Box',
];
