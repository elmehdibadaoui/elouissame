<?php

return [
    'invalid' 			       => 'Ogiltig JSON',
    'invalid_message' 	 => 'Verkar som du har angett ogiltig JSON.',
    'valid' 			         => 'Giltig JSON',
    'validation_errors' => 'Valideringsfel',
];
