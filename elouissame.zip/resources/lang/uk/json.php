<?php

return [
    'invalid'           => 'неправильний формат JSON',
    'invalid_message'   => 'Введено неправильний формат JSON',
    'valid'             => 'Правильний формат JSON',
    'validation_errors' => 'Помилки при перевірці даних',
];
