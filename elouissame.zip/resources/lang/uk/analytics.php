<?php

return [
    'by_pageview'            => 'По сторінках',
    'by_sessions'            => 'По сесіях',
    'by_users'               => 'По користувачах',
    'no_client_id'           => 'Для активації аналітики необхідно отримати ідентифікатор клієнта Google Analytics та додати його в поле <code>google_analytics_client_id</code> меню налаштувань. Отримати код Google Analytics: ',
    'set_view'               => 'Виберіть вид',
    'this_vs_last_week'      => 'Поточний тиждень в порівнянні з попереднім.',
    'this_vs_last_year'      => 'Поточний рік в порівнянні з попереднім',
    'top_browsers'           => 'Найкращі браузери',
    'top_countries'          => 'Найкращі країни',
    'various_visualizations' => 'Різноманітні візуалізації',
];
