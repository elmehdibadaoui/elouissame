<?php

return [
    'field_password_keep'          => 'Залиште порожнім, якщо не хочете змінювати пароль',
    'field_select_dd_relationship' => 'Обов\'язково налаштуйте відповідні стосунки (relationship) в методі :method класу :class.',
    'type_checkbox'                => 'Чекбокс',
    'type_codeeditor'              => 'Редактор коду',
    'type_file'                    => 'Файл',
    'type_image'                   => 'Зображення',
    'type_radiobutton'             => 'Радіо-кнопка',
    'type_richtextbox'             => 'Візуальний редактор',
    'type_selectdropdown'          => 'Випадаючий список',
    'type_textarea'                => 'Текстове поле',
    'type_textbox'                 => 'Поле вводу',
];
