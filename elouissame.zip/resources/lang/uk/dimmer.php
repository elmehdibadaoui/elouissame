<?php

return [
    'page'           => 'сторінка|сторінки',
    'page_link_text' => 'Всі сторінки',
    'page_text'      => 'В базі даних :count :string',
    'post'           => 'запис|записи',
    'post_link_text' => 'Всі записи',
    'post_text'      => 'В базі даних :count :string',
    'user'           => 'користувач|користувачів',
    'user_link_text' => 'Всі користувачі',
    'user_text'      => 'В базі даних :count :string',
];
