<?php

return [
    'last_week' => 'Минулого тижня',
    'last_year' => 'Минулого року',
    'this_week' => 'Цього тижня',
    'this_year' => 'Цього року',
];
