<?php

return [
    'footer_copyright'  => 'Зроблено з <i class="voyager-heart"></i> ',
    'footer_copyright2' => 'Зроблено під ромом :) ',
];
