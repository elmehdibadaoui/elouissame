<?php

return [
    'avatar'        => 'Avatar',
    'edit'          => 'Mein Profil bearbeiten',
    'edit_user'     => 'Benutzer bearbeiten',
    'password'      => 'Passwort',
    'password_hint' => 'Leer lassen um das Bisherige zu behalten',
    'role'          => 'Rolle',
    'user_role'     => 'Benutzerrolle',
];
