<?php

return [
    'footer_copyright'  => 'Tehtiin <i class="voyager-heart"></i> kanssa',
    'footer_copyright2' => 'Tehtiin rommin ja lisärommin kanssa',
];
