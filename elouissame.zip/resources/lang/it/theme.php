<?php

return [
    'footer_copyright'  => 'Realizzato con <i class="voyager-heart"></i> da',
    'footer_copyright2' => 'Realizzato con rum, e poi ancora rum',
];
