<?php

return [
    'field_password_keep'          => 'Lasciare vuoto per mantenere lo stesso',
    'field_select_dd_relationship' => 'Assicurarsi di impostare la relazione appropriata nel metodo :method della classe :class .',
    'type_checkbox'                => 'Check Box',
    'type_codeeditor'              => 'Editore del Codice',
    'type_file'                    => 'File',
    'type_image'                   => 'Immagine',
    'type_radiobutton'             => 'Radio Button',
    'type_richtextbox'             => 'Rich Textbox',
    'type_selectdropdown'          => 'Select Dropdown',
    'type_textarea'                => 'Text Area',
    'type_textbox'                 => 'Text Box',
];
