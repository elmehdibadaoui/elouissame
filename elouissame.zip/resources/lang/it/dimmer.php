<?php

return [
    'page'           => 'Pagina|Pagine',
    'page_link_text' => 'Visualizza tutte le pagine',
    'page_text'      => 'Ci sono :count :string nel tuo database. Premi il bottone qui sotto per vedere tutte le pagine.',
    'post'           => 'Articolo|Articoli',
    'post_link_text' => 'Visualizza tutti gli articoli',
    'post_text'      => 'Ci sono :count :string nel tuo database. Premi il bottone qui sotto per vedere tutti gli articoli.',
    'user'           => 'Utente|Utenti',
    'user_link_text' => 'Visualizza tutti gli utenti',
    'user_text'      => 'Ci sono :count :string nel tuo database. Premi il bottone qui sotto per vedere tutti gli utenti.',
];
